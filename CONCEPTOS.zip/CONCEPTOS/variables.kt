Variables
Una variable es un espacio de memoria donde se almacena un valor que puede cambiar durante la ejecución del programa.

Sintaxis:

var miVariable = 10
var nombre = "Juan"
