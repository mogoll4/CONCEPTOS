Constantes
Una constante es un espacio de memoria donde se almacena un valor que no puede cambiar durante la ejecución del programa.

Sintaxis:

val PI = 3.14159
