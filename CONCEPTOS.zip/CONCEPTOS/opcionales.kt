Opcionales
En Kotlin, se utilizan tipos que pueden aceptar valores nulos para representar valores opcionales.

Sintaxis:

var nombre: String? = null
nombre = "Juan"
