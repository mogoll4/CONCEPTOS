Nulos
El valor null representa la ausencia de valor o una referencia vacía.

Sintaxis:

var miVariable: String? = null
